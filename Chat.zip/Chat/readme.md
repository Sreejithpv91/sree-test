You are required to build a chat application, where users can create rooms, join, and have conversations. There must be 2 inputs:

Username
Room name
After adding the inputs, the user should be able to do the following:

Enter a specific chat room where they can communicate with other users
Send a live location to every user
Task
Your task is to complete the incomplete code in these files by following the instructions provided in the project:

server.js
Use frontend>public>js>setconnection.js as a reference to complete the code given in the server.js file.