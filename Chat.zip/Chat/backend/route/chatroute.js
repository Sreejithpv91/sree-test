const express = require ('express')
const route = new express.Router ();

//We want this route now, because we want static html page to be front page
// route.get ('/', (req, res) => {
// 	res.render ("frontpage", {
// 		title : "CHAT APPLICATION",
// 		name : "PARUL BANSAL"
// 	})
// })

route.get ('/', (req, res) => {
	res.status(200);
	res.render("chat")
})

route.get ('/frontpage', (req, res) => {
	res.status(200);
	res.render ("frontpage")
})

route.get ('/about', (req, res) => {
	res.status(200);
	res.render ("about", {
		title : "ABOUT",
		name : "PARUL BANSAL",
		message : "This is under construction"
	})
})

module.exports = route