const app = require('./app.js')
const server = require('./server.js')
const port = process.env.PORT || 8000

//For sending google map location use
//https://google.com/maps?q=latitude,longitude
server.listen (port, () => {
	console.log ("Your Server is running on " + port)
})