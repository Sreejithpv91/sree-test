const request = require ('supertest')
const {addUser, removeUser, getUser, getUsersInRoom} = require ('../utils/User')

describe("testing User.js", () => {
    const user = {
        id : '1',
        username: "parul",
        room : "1"
    }

    test ("addUser_requireUsername", async() => {
        const response = await addUser({
            id : '1',
            room: "1"
        })
        expect(response).toMatchObject({
            error: "Username is required!"
        })
    })

    test ("addUser__requireRoomName", async() => {
        const response = await addUser({
            id : '1',
            username: "Demo"
        })
        expect(response).toMatchObject({
            error: "Room Name is required"
        })
    })

    test ("addUser__addUser", async() => {
        const response = await addUser(user)
        expect(response).toMatchObject(
            user
        )
        removeUser(user.id)
    })

    // test ("addUser__existingUser", async() => {
    //     const r1 = await addUser(user)
    //     const response = await addUser(user)
    //     expect(response).toMatchObject({error : "Username Already In Use"})
    //     removeUser(user.id)
    // })

    test ("getUser__existing", async() => {
        addUser(user)
        const response = await getUser(user.id)
        expect(response).toMatchObject(user)
        removeUser(user.id)
    })

    // test ("getAllUsers", async() => {
    //     await addUser(user)
    //     const temp = {
    //         username: "bparul",
    //         room : "1",
    //         id : "2"
    //     }
    //     await addUser(temp)
    //     const response = await getUsersInRoom(user.room)
    //     expect({ans: response}).toMatchObject({ans: [user, temp]})
    //     removeUser(user.id)
    //     removeUser(temp.id)
    // })

    test ("removeUser__existingUser", async() => {
        addUser(user)
        const response = await removeUser(user.id)
        expect(response).toMatchObject(user)
    })

    test("removeUser__nonExistingUser", async()=>{
        const response = await removeUser(user.id)
        expect(response).toMatchObject({error: ''})
    })

    test ("getUser__nonexisting", async() => {
        const response = await getUser(user.id)
        expect(response).toMatchObject({error: ''})
    })
})