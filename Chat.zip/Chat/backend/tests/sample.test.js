const {getTime, getLocationTime} = require('../utils/timeStamp')
const request = require ('supertest')

describe("testing timeStamp.js",  () => {
    test("testing getTime", async() => {
        const response = getTime("bparul", "Welcome");
        expect(response).toMatchObject({
            username: "bparul",
            text: "Welcome"
        })
    })

    
})