const express = require ('express')
const app = express ();

//route
const chatroute = require ('./route/chatroute.js')

//hbs
const hbs = require ('hbs')
const path = require ('path')
console.log (__dirname);

//find all paths
//partial path
const path_partial = path.join (__dirname, '../frontend/partial/headerpartials')
//views path
const path_view = path.join (__dirname, '../frontend/partial/view')
//css, js path
const path_public = path.join (__dirname, '../frontend/public')

//configure express to use css, js (static content)
//whatever is inside it, it will show it
app.use (express.static (path_public))

//configure express to use views
app.set ('view engine', 'hbs')
app.set ('views', path_view)

//set up routes for views
app.use (express.json())
app.use (chatroute)

//configure express to use partials
hbs.registerPartials (path_partial)

module.exports = app;