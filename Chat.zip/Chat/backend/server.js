const app = require('./app.js')
const http = require ('http')
const socketio = require ('socket.io')
const Filter = require ('bad-words')
const {getTime, getLocationTime} = require ('./utils/timeStamp.js')
const {addUser, removeUser, getUser, getUsersInRoom} = require ('./utils/User.js')

//set up server
const server = http.createServer (app)
const io = socketio (server)

//io events
//Server accepts connection request and send welcome message

//Whenever server is sending message to all clients, it should send : Date - Message
io.on ('connection', (socket) => {
    console.log ("NEW CONNECTION REQUEST")
    socket.on ('join', ({username, room}, callback) => {
        const {error, user} = addUser ({id : socket.id, username, room});
        if (error) {
            return callback (error)
        }


    console.log (user)
    //user user object now, cause username and room may be formatted by addUser
   
    /*
    complete the function, When a new user joins, 
    He show be shown with the Username xyz has joined 
    with the current time stamp in the current room 
    */

     
    })

    const filter = new Filter();
    socket.on ("Send", (data, callback) => {

    /* 
    On clicking Send button, the message should be sent, and the 
    username should be shown, also the current time stamp. profane 
    words or cuss words are not allowed.
    */
    
    })

    socket.on ("SendLocation", (coords, callback) => {

        /*
        On clicking on send location button, the function 
        should send the current location of the system using geolocation. 
        The error should be shown if error persists  
        */

    })

    socket.on ("disconnect", () => {

        /*
        If a user leaves the room, a message from Admin should be 
        shown with a current timestamp, that user xyz left the chat 
        to the other members over the room.
        */

    })
})

module.exports = server;
