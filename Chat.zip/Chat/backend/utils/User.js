const User = []; //userlist

const addUser = ({id, username, room}) => {
	//Validate the data and add user to userlist if validation passes.
	/* Return object of form: 
		id : '',
        username: "",
        room : ""
	*/
	/*Return errors if validation fails of the form:
		{
            error: "Username is required!"
        }
		{
            error: "Room Name is required"
        }
		{
			error : "Username Already In Use"
		}
	*/
}

const removeUser = (id) => {
	/*
		Return deleted user object if found else return {error:''}.
	*/
}

const getUser = (id) => {
	/* Return object of form: 
		id : '',
        username: "",
        room : ""
	*/
	//Return error if not found : {error:''}
	
} 

const getUsersInRoom = (room) => {
	/*Return array of user objects of form
		{
			ans: [{},{}]
		}
	*/
}

module.exports = {
	addUser,
	removeUser,
	getUser,
	getUsersInRoom
}