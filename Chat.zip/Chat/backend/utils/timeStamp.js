const getTime = (username, msg) => {
	//Return object with fields 'username','text','time'
	const ans = {

	};
	return ans
}

const getLocationTime = (username, url) => {
	//Return object with 'username','url' and 'createdAt'
	const ans ={

	}
	return ans;
}

module.exports = {
	getTime,
	getLocationTime
}